
public class Equal {


	public static void main(String[] args) {
	
String s1="hello";
String s2="hello";
if(s1.equals(s2)){
System.out.println("hello");
	}}

}
